
# Sistema de Aluguel de Kitnets

## Descrição
Este projeto é um sistema de aluguel de kitnets, com funcionalidades de CRUD para gerenciar as kitnets e autenticação de usuários.

## Como Rodar o Projeto

1. Clone o repositório ou faça o download do código.
2. Navegue até a pasta `src/Api` e execute o comando para restaurar as dependências:
   ```bash
   dotnet restore
   ```
3. Crie a migração e aplique no banco de dados:
   ```bash
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```
4. Execute o projeto:
   ```bash
   dotnet run
   ```
5. Acesse a API via Swagger:
   ```bash
   http://localhost:5117/swagger
   ```

## Testes Automatizados

Para rodar os testes automatizados, execute:
```bash
dotnet test
```

Os testes cobrem as operações de CRUD de kitnets e o login de usuários.

## Endpoints

- **POST /api/auth/register**: Cria um novo usuário.
- **POST /api/auth/login**: Realiza o login e gera um token JWT.
- **GET /api/kitnet**: Lista todas as kitnets.
- **POST /api/kitnet**: Cria uma nova kitnet.
- **PUT /api/kitnet/{id}**: Atualiza uma kitnet existente.
- **DELETE /api/kitnet/{id}**: Deleta uma kitnet.
