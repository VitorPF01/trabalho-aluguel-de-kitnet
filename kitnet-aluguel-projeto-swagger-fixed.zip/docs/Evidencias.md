# Documento de Evidências

Neste documento devem ser inseridos:

* Prints do cronograma/board de tarefas
* Prints do Docker rodando o SQL Server
* Print do terminal com `dotnet run`
* Print do Swagger em `http://localhost:5000/swagger`
* Print de chamadas a endpoints (Postman/Insomnia ou próprio Swagger)
* Print do resultado de `dotnet test`

Use cabeçalho com nome do aluno, disciplina, professor e turma.
